/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.poo;

/**
 *
 * @author melissapereira
 */
public class Bar extends Pdi{
    String nome;
    double rating;
    double consumo;

    public Bar(Horario time, double entrada, double opiniao, String Nome) {
        super(time);
        consumo = entrada;
        rating = opiniao;
        nome = Nome;
    }
    @Override
    public double custo(){
       return consumo; 
    }
    
    
}
