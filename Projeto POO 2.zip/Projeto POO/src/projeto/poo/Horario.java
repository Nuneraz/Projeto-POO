/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.poo;

/**
 *
 * @author melissapereira
 */
public class Horario {
    double abertura;
    double encerramento;
    
    public Horario(double Abertura, double Encerramento) {
        abertura = Abertura;
        encerramento = Encerramento;
    }
    
}
