/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.poo;

/**
 *
 * @author xamxam
 */
public class Aquatico extends Parque {
    String equipamento;
    Boolean shows;

    public Aquatico(String Nome, double Entrada, Horario time,String equip,Boolean hasshows) {
        super(Nome, Entrada, time);
        equipamento = equip;
        shows = hasshows;
    }
    
    @Override
    public double custo(){
        return entrada;
    }

    
}
