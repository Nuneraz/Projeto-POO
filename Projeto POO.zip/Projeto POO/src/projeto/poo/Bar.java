/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.poo;

/**
 *
 * @author melissapereira
 */
public class Bar extends Pdi{
    String nome;
    double rating;
    double consumo;
    
    public Bar(String Nome, double Rating, double Consumo, Horario time){
        nome = Nome;
        rating = Rating;
        consumo = Consumo;
        horas = time;
    }
    
    
}
