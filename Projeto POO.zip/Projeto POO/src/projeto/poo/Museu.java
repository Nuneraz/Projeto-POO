/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto.poo;

/**
 *
 * @author melissapereira
 */
public class Museu extends Pdi {
    String nome;
    String tematica;
    double entrada;
    
    public Museu (String Nome, String Tematica, double Entrada, Horario time){
        nome = Nome;
        tematica = Tematica;
        entrada = Entrada;
        horas = time;
                
    }
    
}
